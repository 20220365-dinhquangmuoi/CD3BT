import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

# Load data
df = pd.read_csv("social_media_dataset.csv")

# Clean
df = df.drop_duplicates()
df = df.fillna(df.mean(numeric_only=True))

# 1. Histogram Age
plt.figure()
df['Age'].hist()
plt.title("Histogram Age")
plt.savefig("hinh_3_1_age.png")

# 2. Histogram Usage
plt.figure()
df['Daily_Usage_Time'].hist()
plt.title("Usage Time")
plt.savefig("hinh_3_1_usage.png")

# 3. Heatmap
plt.figure()
plt.imshow(df.corr(numeric_only=True))
plt.colorbar()
plt.savefig("hinh_3_2_heatmap.png")

# 4. Likes vs Engagement
plt.figure()
plt.scatter(df['Likes_Received'], df['Engagement_Score'])
plt.savefig("hinh_3_4.png")

# 5. Followers vs Engagement
plt.figure()
plt.scatter(df['Followers'], df['Engagement_Score'])
plt.savefig("hinh_3_5.png")

# 6. Boxplot
plt.figure()
df.boxplot(column='Engagement_Score', by='Platform')
plt.savefig("hinh_3_6.png")

# 7. Model
X = df[['Daily_Usage_Time','Posts_Per_Week','Likes_Received','Comments_Received','Followers']]
y = df['Engagement_Score']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

plt.figure()
plt.scatter(y_test, y_pred)
plt.savefig("hinh_3_7.png")